#include "CalculateExponential.hpp"
#include <iostream>

void CalculateExponential(ComplexNumber **A, int nMax, ComplexNumber **res) {
    // For simplicity, assume 2x2 matrix
    // Initialize result to identity matrix
    res[0][0] = ComplexNumber(1, 0);
    res[0][1] = ComplexNumber(0, 0);
    res[1][0] = ComplexNumber(0, 0);
    res[1][1] = ComplexNumber(1, 0);
    
    // Compute e^A = I + A + A^2/2! + A^3/3! + ... + A^nMax/nMax!
    ComplexNumber **A_power = new ComplexNumber*[2];
    A_power[0] = new ComplexNumber[2];
    A_power[1] = new ComplexNumber[2];
    
    // Initialize A_power to A (first power)
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            A_power[i][j] = A[i][j];
        }
    }
    
    double factorial = 1.0;
    
    for (int n = 1; n <= nMax; n++) {
        factorial *= n;
        
        // Add A^n / n! to result
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                res[i][j] = res[i][j] + (A_power[i][j] * (1.0 / factorial));
            }
        }
        
        // Compute A^(n+1) = A^n * A
        if (n < nMax) {
            ComplexNumber **temp = new ComplexNumber*[2];
            temp[0] = new ComplexNumber[2];
            temp[1] = new ComplexNumber[2];
            
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    temp[i][j] = ComplexNumber(0, 0);
                    for (int k = 0; k < 2; k++) {
                        temp[i][j] = temp[i][j] + (A_power[i][k] * A[k][j]);
                    }
                }
            }
            
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    A_power[i][j] = temp[i][j];
                }
            }
            
            delete[] temp[0];
            delete[] temp[1];
            delete[] temp;
        }
    }
    
    delete[] A_power[0];
    delete[] A_power[1];
    delete[] A_power;
}

void printMatrix(ComplexNumber **A, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << A[i][j] << " ";
        }
        std::cout << std::endl;
    }
}
