#include "GraduateStudent.hpp"

GraduateStudent::GraduateStudent() : Student(), fullTime(false) {}

GraduateStudent::GraduateStudent(std::string name, double fines, double fees, bool ft) 
    : Student(name, fines, fees), fullTime(ft) {}

double GraduateStudent::MoneyOwed() const {
    double base = Student::MoneyOwed();
    if (fullTime) {
        return base * 0.5;  // Full-time graduate students pay 50% of total
    } else {
        return base;
    }
}
