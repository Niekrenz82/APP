#include "PhdStudent.hpp"

PhdStudent::PhdStudent(std::string name, double fines, double fees, bool ft) 
    : GraduateStudent(name, fines, fees, ft) {}

double PhdStudent::MoneyOwed() const {
    double base = Student::MoneyOwed();  // Call grandparent to get full amount
    return base * 0.1;  // PhD students pay 10% of total
}
